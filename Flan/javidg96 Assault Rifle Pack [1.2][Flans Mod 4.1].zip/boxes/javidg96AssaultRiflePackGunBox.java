Name javidg96 Assault Rifle Pack Gun Box
ShortName javidg96AssaultRiflePackGunBox
TopTexture AssaultRiflesBoxTop
SideTexture AssaultRiflesBoxSide
BottomTexture AssaultRiflesBoxBottom
GunBoxID 251
Recipe I iron R redstone S slimeBall 
SSS
IRI
III
NumGuns 22
AddGun MFourAOne 3 iron 1 gunpowder
AddAmmo MFourAOneClip 1 iron 1 gunpowder
AddGun ARFifteen 3 iron 1 gunpowder
AddAmmo ARFifteenClip 1 iron 1 gunpowder
AddGun MSixteenAFour 3 iron 1 gunpowder
AddAmmo MSixteenAFourClip 1 iron 1 gunpowder
AddGun BACR 3 iron 1 gunpowder
AddAmmo BACRClip 1 iron 1 gunpowder
AddGun SCARH 3 iron 1 gunpowder
AddAmmo SCARHClip 1 iron 1 gunpowder
AddGun SCARL 3 iron 1 gunpowder
AddAmmo SCARLClip 1 iron 1 gunpowder
AddGun ColtCM 3 iron 1 gunpowder
AddAmmo ColtCMClip 1 iron 1 gunpowder
AddGun MKFourteenEBR 3 iron 1 gunpowder
AddAmmo MKFourteenEBRClip 1 iron 1 gunpowder
AddGun SAUG 3 iron 1 gunpowder
AddAmmo SAUGClip 1 iron 1 gunpowder
AddGun FNFAL 3 iron 1 gunpowder
AddAmmo FNFALClip 1 iron 1 gunpowder
AddGun FNF 3 iron 1 gunpowder
AddAmmo FNFClip 1 iron 1 gunpowder
AddGun FNFS 3 iron 1 gunpowder
AddAmmo FNFClip 1 iron 1 gunpowder
AddGun GThirtysixV 3 iron 1 gunpowder
AddAmmo GThirtysixVClip 1 iron 1 gunpowder
AddGun HKGThree 3 iron 1 gunpowder
AddAmmo HKGThreeClip 1 iron 1 gunpowder
AddGun CetmeLV 3 iron 1 gunpowder
AddAmmo CetmeLVClip 1 iron 1 gunpowder
AddGun BerettaARX160 3 iron 1 gunpowder
AddAmmo BerettaARX160Clip 1 iron 1 gunpowder
AddAltAmmo BerettaARX160Drum 2 iron 2 gunpowder
AddGun FAMASFOne 3 iron 1 gunpowder
AddAmmo FAMASFOneClip 1 iron 1 gunpowder
AddGun FAMASCommando 3 iron 1 gunpowder
AddAmmo FAMASCommandoClip 1 iron 1 gunpowder
AddGun SIGSGCommando 3 iron 1 gunpowder
AddAmmo SIGSGCommandoClip 1 iron 1 gunpowder
AddGun GalilSAR 3 iron 1 gunpowder
AddAmmo GalilSARClip 1 iron 1 gunpowder
AddGun AKFourtyseven 3 iron 1 gunpowder
AddAmmo AKFourtysevenClip 1 iron 1 gunpowder
AddGun CTARTwentyone 3 iron 1 gunpowder
AddAmmo CTARTwentyoneClip 1 iron 1 gunpowder