Name FAMAS F1
ShortName FAMASFOne
Ammo FAMASFOneClip
Icon FAMASF1
Colour 255 255 255
ItemID 30082
ReloadTime 40
Recoil 1
NumBullets 1
Damage 3
Accuracy 2
ShootDelay 1
ShootSound FAMASF1Shoot
ReloadSound FAMASF1Reload
Mode FullAuto
Scope None
ZoomLevel 1.5
Deployable False
DeployedModel None