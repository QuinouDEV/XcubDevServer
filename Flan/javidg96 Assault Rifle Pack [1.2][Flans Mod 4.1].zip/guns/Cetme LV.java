Name Cetme LV
ShortName CetmeLV
Ammo CetmeLVClip
Icon CetmeLV
Colour 255 255 255
ItemID 30077
ReloadTime 40
Recoil 1
NumBullets 1
Damage 3
Accuracy 2
ShootDelay 2
ShootSound CetmeLVShoot
ReloadSound CetmeLVReload
Mode FullAuto
Scope ACOG
ZoomLevel 3.5
Deployable False
DeployedModel None