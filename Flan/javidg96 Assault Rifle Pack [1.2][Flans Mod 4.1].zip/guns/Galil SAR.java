Name Galil SAR
ShortName GalilSAR
Ammo GalilSARClip
Icon GalilSAR
Colour 255 255 255
ItemID 30088
ReloadTime 60
Recoil 1
NumBullets 1
Damage 3
Accuracy 3
ShootDelay 2
ShootSound GalilSARShoot
ReloadSound GalilSARReload
Mode FullAuto
Scope ACOG
ZoomLevel 3.5
Deployable False
DeployedModel None