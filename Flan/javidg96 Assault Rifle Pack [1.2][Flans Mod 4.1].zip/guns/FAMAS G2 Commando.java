Name FAMAS G2 Commando
ShortName FAMASCommando
Ammo FAMASCommandoClip
Icon FAMASG2Commando
Colour 255 255 255
ItemID 30084
ReloadTime 40
Recoil 1
NumBullets 3
Damage 3
Accuracy 2
ShootDelay 1
ShootSound FAMASG2CommandoShoot
ReloadSound FAMASG2CommandoReload
Mode SemiAuto
Scope Holographic
ZoomLevel 1.5
Deployable False
DeployedModel None