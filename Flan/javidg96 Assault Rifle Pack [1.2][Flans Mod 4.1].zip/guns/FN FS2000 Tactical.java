Name FN FS2000 Tactical
ShortName FNFS
Ammo FNFClip
Icon FNFS2000Tactical
Colour 255 255 255
ItemID 30071
ReloadTime 58
Recoil 1
NumBullets 1
Damage 3
Accuracy 3
ShootDelay 2
ShootSound FNFS2000Shoot
ReloadSound FNFS2000Reload
Mode FullAuto
Scope ACOG
ZoomLevel 3.5
Deployable False
DeployedModel None