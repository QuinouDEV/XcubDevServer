Name Colt CM901
ShortName ColtCM
Ammo ColtCMClip
Icon ColtCM901
Colour 255 255 255
ItemID 30062
ReloadTime 60
Recoil 1
NumBullets 1
Damage 4
Accuracy 2
ShootDelay 2
ShootSound ColtCM901Shoot
ReloadSound ColtCM901Reload
Mode FullAuto
Scope ACOG
ZoomLevel 3.5
Deployable False
DeployedModel None