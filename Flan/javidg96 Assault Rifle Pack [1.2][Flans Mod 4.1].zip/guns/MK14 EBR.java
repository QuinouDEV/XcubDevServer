Name MK14 EBR
ShortName MKFourteenEBR
Ammo MKFourteenEBRClip
Icon MK14EBR
Colour 255 255 255
ItemID 30064
ReloadTime 56
Recoil 1
NumBullets 1
Damage 5
Accuracy 1
ShootDelay 2
ShootSound MK14EBRShoot
ReloadSound MK14EBRReload
Mode SemiAuto
Scope Sniper
ZoomLevel 6
Deployable False
DeployedModel None