Name M4A1 Carbine
ShortName MFourAOne
Ammo MFourAOneClip
Icon M4A1Carbine
Colour 255 255 255
ItemID 30050
ReloadTime 42
Recoil 1
NumBullets 1
Damage 4
Accuracy 3
ShootDelay 2
ShootSound M4A1Shoot
ReloadSound M4A1Reload
Mode FullAuto
Scope ACOG
ZoomLevel 3.5
Deployable False
DeployedModel None