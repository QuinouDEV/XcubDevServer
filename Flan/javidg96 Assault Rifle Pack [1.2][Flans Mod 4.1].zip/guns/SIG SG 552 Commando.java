Name SIG SG 552 Commando
ShortName SIGSGCommando
Ammo SIGSGCommandoClip
Icon SIGSG552Commando
Colour 255 255 255
ItemID 30086
ReloadTime 37
Recoil 1
NumBullets 1
Damage 4
Accuracy 3
ShootDelay 2
ShootSound SIGSG552CommandoShoot
ReloadSound SIGSG552CommandoReload
Mode FullAuto
Scope ACOG
ZoomLevel 3.5
Deployable False
DeployedModel None