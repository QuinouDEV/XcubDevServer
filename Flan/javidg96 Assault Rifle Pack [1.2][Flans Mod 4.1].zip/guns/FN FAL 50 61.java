Name FN FAL 50.61
ShortName FNFAL
Ammo FNFALClip
Icon FNFAL
Colour 255 255 255
ItemID 30068
ReloadTime 60
Recoil 1
NumBullets 1
Damage 3
Accuracy 2
ShootDelay 2
ShootSound FNFALShoot
ReloadSound FNFALReload
Mode SemiAuto
Scope None
ZoomLevel 1.5
Deployable False
DeployedModel None