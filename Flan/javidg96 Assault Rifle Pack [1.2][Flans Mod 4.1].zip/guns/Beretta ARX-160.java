Name Beretta ARX-160
ShortName BerettaARX160
Ammo BerettaARX160Clip
Ammo BerettaARX160Drum
Icon BerettaARX-160
Colour 255 255 255
ItemID 30079
ReloadTime 28
Recoil 1
NumBullets 1
Damage 3
Accuracy 2
ShootDelay 2
ShootSound BerettaARX-160Shoot
ReloadSound BerettaARX-160Reload
Mode FullAuto
Scope ACOG
ZoomLevel 3.5
Deployable False
DeployedModel None