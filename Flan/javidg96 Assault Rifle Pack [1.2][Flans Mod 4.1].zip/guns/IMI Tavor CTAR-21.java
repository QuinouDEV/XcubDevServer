Name IMI Tavor CTAR-21
ShortName CTARTwentyone
Ammo CTARTwentyoneClip
Icon IMITavorCTAR-21
Colour 255 255 255
ItemID 30092
ReloadTime 51
Recoil 1
NumBullets 1
Damage 3
Accuracy 3
ShootDelay 2
ShootSound IMITavorCTAR-21Shoot
ReloadSound IMITavorCTAR-21Reload
Mode FullAuto
Scope Holographic
ZoomLevel 1.5
Deployable False
DeployedModel None