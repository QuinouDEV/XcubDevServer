Name Steyr AUG
ShortName SAUG
Ammo SAUGClip
Icon SteyrAUG
Colour 255 255 255
ItemID 30066
ReloadTime 74
Recoil 1
NumBullets 1
Damage 3
Accuracy 2
ShootDelay 2
ShootSound AUGShoot
ReloadSound AUGReload
Mode FullAuto
Scope ACOG
ZoomLevel 3.5
Deployable False
DeployedModel None