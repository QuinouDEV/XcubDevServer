Name HK G3
ShortName HKGThree
Ammo HKGThreeClip
Icon HKG3
Colour 255 255 255
ItemID 30075
ReloadTime 40
Recoil 1
NumBullets 1
Damage 4
Accuracy 2
ShootDelay 2
ShootSound HKG3Shoot
ReloadSound HKG3Reload
Mode FullAuto
Scope None
ZoomLevel 1.5
Deployable False
DeployedModel None