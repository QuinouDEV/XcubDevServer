Name Bushmaster ACR
ShortName BACR
Ammo BACRClip
Icon BushmasterACR
Colour 255 255 255
ItemID 30056
ReloadTime 39
Recoil 1
NumBullets 1
Damage 5
Accuracy 2
ShootDelay 2
ShootSound ACRShoot
ReloadSound ACRReload
Mode FullAuto
Scope None
ZoomLevel 1.5
Deployable False
DeployedModel None