Name FN F2000
ShortName FNF
Ammo FNFClip
Icon FNF2000
Colour 255 255 255
ItemID 30070
ReloadTime 58
Recoil 1
NumBullets 1
Damage 3
Accuracy 2
ShootDelay 2
ShootSound FNF2000Shoot
ReloadSound FNF2000Reload
Mode FullAuto
Scope None
ZoomLevel 1.5
Deployable False
DeployedModel None