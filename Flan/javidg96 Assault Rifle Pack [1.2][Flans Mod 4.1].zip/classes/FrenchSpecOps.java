Name French Spec Ops
ShortName FrenchSpecOps
AddItem FAMASCommando
AddItem FAMASCommandoClip 4