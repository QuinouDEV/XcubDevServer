Name US Rifleman (SCAR-L)
ShortName USRiflemanSCARL
AddItem SCARL
AddItem SCARLClip 4