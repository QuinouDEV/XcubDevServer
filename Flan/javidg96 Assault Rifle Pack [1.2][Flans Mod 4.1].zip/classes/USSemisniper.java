Name US Semisniper
ShortName USSemisniper
AddItem MKFourteenEBR
AddItem MKFourteenEBRClip 4