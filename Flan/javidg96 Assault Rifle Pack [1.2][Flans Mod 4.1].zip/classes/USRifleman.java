Name US Rifleman
ShortName USRifleman
AddItem MFourAOne
AddItem MFourAOneClip 4