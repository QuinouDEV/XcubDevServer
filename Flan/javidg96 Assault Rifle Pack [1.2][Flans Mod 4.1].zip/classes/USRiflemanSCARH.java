Name US Rifleman (SCAR-H)
ShortName USRiflemanSCARH
AddItem SCARH
AddItem SCARHClip 4