Name 5.56x45 NATO Clip (FAMAS F1)
ShortName FAMASFOneClip
Model Bullet
MaxStackSize 4
Colour 255 255 255
ItemID 30083
Icon FAMASF1Clip
FallSpeed 1
RoundsPerItem 25
Damage 1
Explosion 0
ExplodeOnImpact False
Fuse 0
FlakParticles 1
Fire 0
BreaksGlass True
HitBoxSize 0.1
HitSound bullet
Penetrates False
SmokeTrail False