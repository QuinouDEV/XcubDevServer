Name 7.62x39 M43 Clip (AK-47)
ShortName AKFourtysevenClip
Model Bullet
MaxStackSize 4
Colour 255 255 255
ItemID 30091
Icon AK-47Clip
FallSpeed 1
RoundsPerItem 30
Damage 1
Explosion 0
ExplodeOnImpact False
Fuse 0
FlakParticles 1
Fire 0
BreaksGlass True
HitBoxSize 0.1
HitSound bullet
Penetrates False
SmokeTrail False