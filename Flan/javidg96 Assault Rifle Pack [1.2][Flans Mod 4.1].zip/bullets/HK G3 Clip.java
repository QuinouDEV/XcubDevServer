Name 7.62x51 NATO Clip (G3)
ShortName HKGThreeClip
Model Bullet
MaxStackSize 4
Colour 255 255 255
ItemID 30076
Icon HKG3Clip
FallSpeed 1
RoundsPerItem 20
Damage 1
Explosion 0
ExplodeOnImpact False
Fuse 0
FlakParticles 1
Fire 0
BreaksGlass True
HitBoxSize 0.1
HitSound bullet
Penetrates False
SmokeTrail False