Name 5.56x45 NATO Drum (ARX-160)
ShortName BerettaARX160Drum
Model Bullet
MaxStackSize 2
Colour 255 255 255
ItemID 30081
Icon ARX-160Drum
FallSpeed 1
RoundsPerItem 100
Damage 1
Explosion 0
ExplodeOnImpact False
Fuse 0
FlakParticles 1
Fire 0
BreaksGlass True
HitBoxSize 0.1
HitSound bullet
Penetrates False
SmokeTrail False