Name 5.56x45 NATO Clip (M4A1)
ShortName MFourAOneClip
Model Bullet
MaxStackSize 4
Colour 255 255 255
ItemID 30051
Icon M4A1Clip
FallSpeed 1
RoundsPerItem 30
Damage 1
Explosion 0
ExplodeOnImpact False
Fuse 0
FlakParticles 1
Fire 0
BreaksGlass True
HitBoxSize 0.1
HitSound bullet
Penetrates False
SmokeTrail False