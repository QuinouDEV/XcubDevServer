Name 5.56x45 NATO Clip (AR-15)
ShortName ARFifteenClip
Model Bullet
MaxStackSize 4
Colour 255 255 255
ItemID 30053
Icon AR-15Clip
FallSpeed 1
RoundsPerItem 20
Damage 1
Explosion 0
ExplodeOnImpact False
Fuse 0
FlakParticles 1
Fire 0
BreaksGlass True
HitBoxSize 0.1
HitSound bullet
Penetrates False
SmokeTrail False