Name 5.56x45 NATO Clip (G36V)
ShortName GThirtysixVClip
Model Bullet
MaxStackSize 4
Colour 255 255 255
ItemID 30074
Icon G36VClip
FallSpeed 1
RoundsPerItem 30
Damage 1
Explosion 0
ExplodeOnImpact False
Fuse 0
FlakParticles 1
Fire 0
BreaksGlass True
HitBoxSize 0.1
HitSound bullet
Penetrates False
SmokeTrail False