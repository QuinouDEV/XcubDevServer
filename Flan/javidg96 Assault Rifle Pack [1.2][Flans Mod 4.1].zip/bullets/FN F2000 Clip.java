Name 5.56x45 NATO Clip (FN F2000)
ShortName FNFClip
Model Bullet
MaxStackSize 4
Colour 255 255 255
ItemID 30072
Icon FNF2000Clip
FallSpeed 1
RoundsPerItem 30
Damage 1
Explosion 0
ExplodeOnImpact True
Fuse 0
FlakParticles 1
Fire 0
BreaksGlass True
HitBoxSize 0.1
HitSound bullet
Penetrates False
SmokeTrail False